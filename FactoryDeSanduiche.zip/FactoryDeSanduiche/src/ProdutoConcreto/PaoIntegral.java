package ProdutoConcreto;

import Interfaces.Pao;

public class PaoIntegral implements Pao {
	public String getTipo() {
		return "Integral";
	}
}
