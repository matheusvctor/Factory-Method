package ProdutoConcreto;

import Interfaces.Ovo;

public class OvoGranja implements Ovo{
	public String getTipo() {
		return "Granja";
	}
}
