package ProdutoConcreto;

import Interfaces.Queijo;

public class QueijoMussarela implements Queijo {
	public String getTipo() {
		return "Mussarela";
	}
}
