package ProdutoConcreto;

import Interfaces.TomateIF;

public class Tomate implements TomateIF {
	public String getTipo() {
		return "Tradicional";
	}
}
