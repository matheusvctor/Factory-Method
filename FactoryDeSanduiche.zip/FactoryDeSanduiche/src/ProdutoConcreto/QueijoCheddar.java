package ProdutoConcreto;

import Interfaces.Queijo;

public class QueijoCheddar implements Queijo {
	public String getTipo() {
		return "Cheddar";
	}
}
