package ProdutoConcreto;

import Interfaces.Ovo;

public class OvoCapoeira implements Ovo {
	public String getTipo() {
		return "Capoeira";
	}
}
