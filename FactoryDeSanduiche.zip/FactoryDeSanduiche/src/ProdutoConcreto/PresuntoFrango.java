package ProdutoConcreto;

import Interfaces.Presunto;

public class PresuntoFrango implements Presunto {
	public String getTipo() {
		return "Frango";
	}
}
