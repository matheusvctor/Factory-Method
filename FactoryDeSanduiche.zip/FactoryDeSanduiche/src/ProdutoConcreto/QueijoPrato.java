package ProdutoConcreto;

import Interfaces.Queijo;

public class QueijoPrato implements Queijo {
	public String getTipo() {
		return "Prato";
	}
}
