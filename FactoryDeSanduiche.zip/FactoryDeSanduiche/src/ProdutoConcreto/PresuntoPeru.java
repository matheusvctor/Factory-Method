package ProdutoConcreto;

import Interfaces.Presunto;

public class PresuntoPeru implements Presunto {
	public String getTipo() {
		return "Peru";
	}
}
