package ProdutoConcreto;

import Interfaces.Pao;

public class PaoBola implements Pao {
	public String getTipo() {
		return "Bola";
	}
}
