package ProdutoConcreto;

import Interfaces.Pao;

public class PaoFrances implements Pao {
	public String getTipo() {
		return "Francês";
	}
}
