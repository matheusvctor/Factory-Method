package Interfaces;

public interface TomateIF {
	String getTipo();
}
