package Interfaces;

public interface Pao {
	String getTipo();
}
