package Interfaces;

public interface Ovo {
	String getTipo();
}
