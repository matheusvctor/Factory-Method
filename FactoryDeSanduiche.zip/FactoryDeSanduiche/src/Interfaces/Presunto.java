package Interfaces;

public interface Presunto {
	String getTipo();
}
