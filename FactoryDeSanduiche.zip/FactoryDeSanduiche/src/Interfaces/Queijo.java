package Interfaces;

public interface Queijo {
	String getTipo();
}
